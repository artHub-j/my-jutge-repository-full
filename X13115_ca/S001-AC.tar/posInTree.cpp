#include "posInTree.hpp"

bool posAux(const BinaryTree<int> &t, int x, list<int> &l)
{
    if (t.isEmpty())
        return false;

    l.push_back(t.getRoot());

    if (t.getRoot() == x)
        return true;

    if (posAux(t.getLeft(), x, l) or posAux(t.getRight(), x, l))
        return true;

    l.pop_back();
    return false;
}

// Pre:  t no té repetits
// Post: retorna la llista de valors que es troben en el camí des de l'arrel
//       fins la posició de x en t. En cas que x no es trobi a t, retorna
//       una llista buida.
list<int> posInTree(const BinaryTree<int> t, int x)
{
    list<int> res = {};
    posAux(t, x, res);
    return res;
}
