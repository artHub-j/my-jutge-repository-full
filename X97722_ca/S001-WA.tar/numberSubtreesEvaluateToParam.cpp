#include "numberSubtreesEvaluateToParam.hpp"
#include "utils.hpp"

int calculateExpressionTree(const BinaryTree<string> &t, int x, int result, int &cont) 
{
    if (t.isEmpty())
        return 0;

    if (t.getLeft().isEmpty() and t.getRight().isEmpty())
        result = mystoi(t.getRoot());

    int esq = calculateExpressionTree(t.getLeft(), x, result, cont);
    int dret = calculateExpressionTree(t.getRight(), x, result, cont);

    if (esq == x or dret == x) {
        cont++;
    }
    
    if (t.getRoot() == "+")
        result = esq + dret;
 
    if (t.getRoot() == "-")
        result = esq - dret;
 
    if (t.getRoot() == "*")
        result = esq * dret;

    return result;
}

int numberSubtreesEvaluateToParam(const BinaryTree<string> &t, int x)
{
    int cont = 0;
    calculateExpressionTree(t, x, 0, cont);
    return cont;
}