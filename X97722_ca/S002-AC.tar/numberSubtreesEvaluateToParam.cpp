#include "numberSubtreesEvaluateToParam.hpp"
#include "utils.hpp"

int calculateExpressionTree(const BinaryTree<string> &t, int x, int &result, int &cont) 
{
    if (t.isEmpty())
        return 0;

    int esq = calculateExpressionTree(t.getLeft(), x, result, cont);
    int dret = calculateExpressionTree(t.getRight(), x, result, cont);

    if (t.getLeft().isEmpty() and t.getRight().isEmpty()) {
        result = mystoi(t.getRoot());
    }
    
    if (t.getRoot() == "+")
        result = esq + dret;
 
    if (t.getRoot() == "-")
        result = esq - (dret);
 
    if (t.getRoot() == "*")
        result = esq * dret;

    if (result == x) {
        cont++;
    }

    return result;
}

int numberSubtreesEvaluateToParam(const BinaryTree<string> &t, int x)
{
    int cont = 0;
    int res = 0;
    calculateExpressionTree(t, x, res, cont);
    return cont;
}