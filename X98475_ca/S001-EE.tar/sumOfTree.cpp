#include "sumOfTree.hpp"

// Pre:
// Post: Retorna la suma dels valors de t
int sumOfTree(BinaryTree<int> t)
{
    int suma = 0;
    if (not t.isEmpty()) {
        int suma_esq = sumOfTree(t.getLeft());
        int suma_dret = sumOfTree(t.getRight());
        
        suma = suma_esq + suma_dret;

        suma += t.getRoot();
    }
    return suma;
}