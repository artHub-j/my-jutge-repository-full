#include "sumOfTree.hpp"

void sumBinaryTreeAux(BinaryTree<int> root, int& sum) {
    if (root.isEmpty()) {
        return;
    }
    sum += root.getRoot();
    sumBinaryTreeAux(root.getLeft(), sum);
    sumBinaryTreeAux(root.getRight(), sum);
}

// Pre:
// Post: Retorna la suma dels valors de t
int sumOfTree(BinaryTree<int> t)
{
    int sum = 0;
    sumBinaryTreeAux(t, sum);
    return sum;
}