#include "sumOfTree.hpp"

// Pre:
// Post: Retorna la suma dels valors de t
int sumOfTree(BinaryTree<int> t)
{
    if (t.isEmpty())
        return 0;

    return t.getRoot() + sumOfTree(t.getLeft()) + sumOfTree(t.getRight());
}