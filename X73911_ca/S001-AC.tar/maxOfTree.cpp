#include "maxOfTree.hpp"

void maxAux(BinaryTree<int> &t, int &max) 
{
    if (t.isEmpty()) 
        return;

    if (t.getRoot() > max)
        max = t.getRoot();

    maxAux(t.getLeft(), max);
    maxAux(t.getRight(), max);

}

// Pre: t és no buit
// Post: Retorna el màxim dels valors de t
int maxOfTree(BinaryTree<int> t)
{
    int max = t.getRoot();
    maxAux(t, max);
    return max;
}
