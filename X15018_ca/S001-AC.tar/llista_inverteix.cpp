#include "llista.hpp"
using namespace std;

void Llista::inverteix()
{
    //Intercanviem el primer i l'ultim node.
    node_llista *p = primer_node;
    
    while (p != NULL)
    {
        node_llista *tmp;
        tmp = p->seg;
        p->seg = p->ant;
        p->ant = tmp;

        p = p->ant;
    }

    node_llista *tmp;
    tmp = primer_node;
    primer_node = ultim_node;
    ultim_node = tmp;
    
}