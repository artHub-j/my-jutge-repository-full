#include "arbreBin.hpp"
using namespace std;

bool compleix_suma_fills(arbreBin<int> a)
{
    bool compleix(true);

    if (not a.es_buit())
    {
        int varrel = a.arrel();
        int suma = 0;
        arbreBin<int> fe = a.fe();
        arbreBin<int> fd = a.fd();

        if (fe.es_buit() and fd.es_buit())
            suma = varrel;

        if (not fe.es_buit())
            suma += fe.arrel();
        if (not fd.es_buit())
            suma += fd.arrel();

        cout << suma << " " << varrel << endl;

        compleix = suma == varrel;

        if (compleix and not fe.es_buit())
            compleix = compleix_suma_fills(fe);
        if (compleix and not fd.es_buit())
            compleix = compleix_suma_fills(fd);

    }

    return compleix;
}

int main ()
{
    arbreBin<int> a;

    cin >> a;
    cout << a << endl;

    if (compleix_suma_fills(a))
        cout << "L'arbre compleix la propietat 'Suma dels fills'." << endl;
    else 
        cout << "L'arbre no compleix la propietat 'Suma dels fills'." << endl;

}