#include<iostream>
#include "LlistaIOParInt.hh"

using namespace std;

void LlegirLlistaParInt(list<ParInt>& l)
// Pre: l és buida; el canal estandar d’entrada conté un nombre
// parell d’enters, acabat pel parell 0 0
// Post: s’han afegit al final de l els parells llegits fins al 0 0 (no inclòs)
{
    ParInt i;
    while(i.llegir())
    {
        l.push_front(i);
        if(i.primer() == 0 and i.segon() == 0) break;
    }
}

void EscriureLlistaParInt(const list<ParInt>& l)
// Pre: cert
// Post: s’han escrit al canal estandar de sortida els elements de l
{
    list<ParInt> aux(l);
    while (not aux.empty())
    {
        aux.back().escriure();
        aux.pop_back();
    }
}