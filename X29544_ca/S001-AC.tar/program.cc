#include <iostream>
#include "LlistaIOParInt.hh"

using namespace std;

int main()
{
    list<ParInt> l;
    int n, cont = 0, suma = 0;

    LlegirLlistaParInt(l);
    cin>>n;

    while(not l.empty())
    {
        if(l.front().primer() == n){
            cont++;
            suma = suma + l.front().segon();
        }
        l.pop_front();
    }

    cout<<n<<" "<<cont<<" "<<suma<<endl;
}
