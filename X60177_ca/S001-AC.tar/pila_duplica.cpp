#include "pila.hpp"
using namespace std;

void Pila::duplica()
{
    node_pila *actual = primer_node;
    while (actual != NULL)
    {
        node_pila *n = new node_pila;
        n->info = actual->info;
        n->seguent = actual->seguent;
        actual->seguent = n;

        actual = n->seguent;
    }
    return;
}