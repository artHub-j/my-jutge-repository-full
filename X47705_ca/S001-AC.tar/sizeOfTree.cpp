#include "sizeOfTree.hpp"

void sizeAux(BinaryTree<int> &t, int &cont) 
{
    if (t.isEmpty())
        return;

    cont++;

    sizeAux(t.getLeft(), cont);
    sizeAux(t.getRight(), cont);

}

// Pre:
// Post: Retorna la mida de t
int sizeOfTree(BinaryTree<int> t)
{
    int cont = 0;
    sizeAux(t, cont);
    return cont;
}
