#include "cua_elimina.hpp"
#include "queueIOpunt.hpp"
using namespace std;

queue<Punt> elimina_punts_auxiliar(queue<Punt> c, queue<Punt> aux, Punt p)
{
    if (c.empty()) return aux;
    else
    {
        if (c.front() == p) c.pop();
        else
        {
            aux.push(c.front());
            c.pop();
        }
    }
    return elimina_punts_auxiliar(c, aux, p);
}

queue<Punt> elimina_punts(queue<Punt> c, Punt p)
/* Pre: c = C i p = P */
/* Post: retorna la cua C on s'han eliminat totes les aparicions del punt P */
{
    queue<Punt> c2;
    return elimina_punts_auxiliar(c, c2, p);
}