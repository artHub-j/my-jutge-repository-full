#include "pila_concatena.hpp"
using namespace std;

void capgirar_piles(stack<int> &s, stack<int> &aux)
{
    if (not s.empty())
    {
        aux.push(s.top());
        s.pop();
        capgirar_piles(s, aux);
    }
    else s = aux;
}

void concatena_piles(stack<int> &p, stack<int> &q)
///POST: posa els elements de q a p. 
{
    if (not q.empty())
    {
        p.push(q.top());
        q.pop();
        concatena_piles(p, q);
    }
}

void concatena_piles(stack<int> &p, stack<int> &q, stack<int> &concatp)
/* Pre: p = P i q = Q i concatp es buida */
/* Post: concatp conte a dalt els elements de P en 
   el mateix ordre, i a sota els elements de Q en el mateix
   ordre */
{
    stack<int> aux;
    capgirar_piles(p, aux);
    concatena_piles(q, p);
    concatp = q;
}