#include "pila_concatena.hpp"

void concatena_piles(stack<int> &p, stack<int> &q, stack<int> &concatp)

{
    stack<int> aux1;
    stack<int> aux2;

    while (not q.empty())
    {
        aux1.push(q.top());
        q.pop();

    }

    while (not p.empty())
    {
        aux2.push(p.top());
        p.pop();
        
    }
    
    while (not aux1.empty())
    {
        concatp.push(aux1.top());
        aux1.pop();
    }
    
    while (not aux2.empty())
    {
        concatp.push(aux2.top());
        aux2.pop();
    }
    
}

