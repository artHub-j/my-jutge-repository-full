#include <iostream>
#include <vector>
#include "stackIOpunt.hpp"
using namespace std;

bool cercalineal(stack<Punt> &sp, Punt x)
/* Pre: cert */
/* Post: el resultat es un boolea que indica si x es troba dins de sp */
{
  bool trobat = false;
  while (not sp.empty() and not trobat) {
    if (sp.top()==x) 
		trobat = true;
    else
		sp.pop();
  }
  
  return trobat;
}

int main() {

	stack<Punt> sp;
	cin>>sp;
	cout<<sp;
	Punt p;
	
	while(cin>>p){
		if(cercalineal(sp, p))
			cout<<"El punt "<<p<<" es torba en la pila."<<endl;
		else 
			cout<<"El punt "<<p<<" no es torba en la pila."<<endl;
	}

}
