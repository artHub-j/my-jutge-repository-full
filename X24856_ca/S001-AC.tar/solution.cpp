#include "cua.hpp"

cua::cua(const vector<int> &v)
{
    _long = v.size();

    if (not v.empty()) {
        node *p, *prim;

        p = new node;
        p->info = v[0];
        prim = p;
        node *nou;
        for (int i = 1; i < v.size(); ++i) {
            nou = new node;
            nou->info = v[i];
            nou->seg = nullptr;
            p->seg = nou;
            p = p->seg;
        }

        _ult = p;
        p->seg = prim;
    }
    else {
        _ult = nullptr;
    }
}
