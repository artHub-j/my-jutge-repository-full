#include "esborraSenars.hpp"

void esborraSenars(stack<int> &P)
{
    if (P.empty()) return ;
    int i = P.top();
    P.pop();
    esborraSenars(P);
    P.push(i);
    if (i % 2 == 0) P.push(i);
    return ;
};