#include "llista_compra_articles.hpp"

int compra_articles(const list<int> &l, int x)
/* Pre: l = L, x > 0 */
/* Post: El resultat es el nombre d'articles de L que podem comprar amb x euros */
{
    int cont = 0;
    for (list<int>::const_iterator it = l.begin(); it != l.end(); ++it) 
    {
        if ((*it) <= x) {
            x -= (*it);
            ++cont;
        }
        else {
            break;
        }
    }   

    return cont;
}