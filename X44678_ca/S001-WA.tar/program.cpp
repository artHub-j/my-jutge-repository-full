#include<iostream>
#include "stackIOpunt.hpp"
#include "queueIOpunt.hpp"

using namespace std;

int main()
{
    queue<Punt> q;
    stack<Punt> s, aux;
    
    cin>>q;
    cout<<q;

    while (not q.empty())
    {
        aux.push(q.front());
        q.pop();
    }

    while (not aux.empty())
    {
        s.push(aux.top());
        aux.pop();
    }
    
    cout<<s;
    cin>>q;
}

