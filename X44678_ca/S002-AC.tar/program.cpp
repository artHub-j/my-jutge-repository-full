#include <iostream>
#include "stackIOpunt.hpp"
#include "queueIOpunt.hpp"

using namespace std;

int main()
{
    queue<Punt> q;
    stack<Punt> s, aux;

    while (cin >> q)
    {
        cout << q;
        while (not q.empty())
        {
            s.push(q.front());
            q.pop();
        }
        while (not s.empty())
        {
            aux.push(s.top());
            s.pop();
        }
        cout << aux;
        while (not aux.empty()) aux.pop();
    }
}
