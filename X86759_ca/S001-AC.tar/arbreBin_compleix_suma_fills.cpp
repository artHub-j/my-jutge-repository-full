#include "arbreBin.hpp"

bool arbreBin::compleix_suma_fills(node_arbre* p)
	/* Pre: true */
	/* Post: Retorna si l'arbre apuntat per p compleix la propietat
	   'Suma dels fills': Per tot node el seu valor és igual a la suma
	   dels valors dels nodes (arrels) del fill esquerre i del fill dret */
{
    bool r;
    if (p == NULL) r = true;
    else if (p->segE == NULL and p->segD == NULL) r = true;
    else
    {
        int sE = 0, sD = 0;
        if (p->segE != NULL) sE = p->segE->info;
        if (p->segD != NULL) sD = p->segD->info;

        r = sE + sD == p->info;
        if (r)
        {   
            r = compleix_suma_fills(p->segE);
            if (r) r = compleix_suma_fills(p->segD);
        }
    }
    return r;
}

bool arbreBin:: compleix_suma_fills() const
	/* Pre: true */
	/* Post: Retorna si compleix la propietat 'Suma dels fills':
	   Per tot node el seu valor és igual a la suma dels valors
	   dels nodes (arrels) del fill esquerre i del fill dret */
{
    return compleix_suma_fills(this->_arrel);
}