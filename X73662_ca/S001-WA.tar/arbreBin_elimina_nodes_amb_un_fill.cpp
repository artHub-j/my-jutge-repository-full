#include "arbreBin.hpp"

arbreBin:: node_arbre* arbreBin::elimina_nodes_amb_un_fill(node_arbre *p)
/* Pre: true */
/* Post: S'han eliminat els nodes de l'arbre apuntat per p que
	   tenen un fill. Retorna el punter on comença l'arbre modificat */
{   
    node_arbre *r;
    if (p->segE == NULL and p->segD == NULL) r = p;
    else if (p->segE != NULL and p->segD != NULL)
    {
        p->segE = elimina_nodes_amb_un_fill(p->segE);
        p->segD = elimina_nodes_amb_un_fill(p->segD);

        r = p;
    }
    else //
    {
        node_arbre* node = p->segD;
        if (p->segE != NULL) node = p->segE;
        r = elimina_nodes_amb_un_fill(node);
        delete p;
    }
    return r;
}

void arbreBin::elimina_nodes_amb_un_fill()
/* Pre: true */
/* Post: S'han eliminat els nodes del p.i. que tenen un fill */
{
    if (_arrel != NULL)
        elimina_nodes_amb_un_fill(_arrel);
}