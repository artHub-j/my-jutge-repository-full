#include "sumOfTree.hpp"
#include <queue>

// Pre:
// Post: Retorna la suma dels valors de t
int sumOfTree(BinaryTree<int> root)
{
    if (root.isEmpty()) {
        return 0;
    }
    
    int sum = 0;
    queue<BinaryTree<int>> q;
    q.push(root);

    while (!q.empty()) {
        BinaryTree<int> current = q.front();
        q.pop();
        sum += current.getRoot();

        if (not current.getLeft().isEmpty()) {
            q.push(current.getLeft());
        }
        if (not current.getRight().isEmpty()) {
            q.push(current.getRight());
        }
    }

    return sum;
}
